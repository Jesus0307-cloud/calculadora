function appendToResult(value) {
    document.getElementById('resultado').value += value;
}

function clearResult() {
    document.getElementById('resultado').value = '';
}

function calculateResult() {
    const resultField = document.getElementById('resultado');
    try {
        resultField.value = eval(resultField.value);
    } catch (error) {
        resultField.value = 'Error';
    }
}
